/**
 * start/template.js
 * @ndaidong
 * @copy: *.techpush.net
*/
var Template = Template || {}
